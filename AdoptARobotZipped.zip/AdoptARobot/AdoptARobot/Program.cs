﻿namespace Adopt_a_Robot
{
    class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game("Super Awesome Adopt-a-Bot Game!");
            game.Start();
        }
    }
}