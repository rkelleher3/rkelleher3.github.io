﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdventureGame
{
    class Choice
    {
        int Counter = 1;
        public Choice()
        {

        }
        public void Decide(string OptionA, string OptionB)
        {
            if (Counter == 1)
            {
                string input;
                Console.WriteLine("Which will you choose? A or B?");
                input = Console.ReadLine();
                input = input.ToUpper();
                if (input == "A")
                {
                    Console.WriteLine($"You have chosen to {OptionA}");
                    Options.Choice1A();
                }
                if (input == "B")
                {
                    Console.WriteLine($"You have chosen to {OptionB}");
                    Options.Choice1B();
                }
            }
            if (Counter == 2)
            {
                string input;
                Console.WriteLine("Which will you choose? A or B?");
                input = Console.ReadLine();
                input = input.ToUpper();
                if (input == "A")
                {
                    Console.WriteLine($"You have chosen to {OptionA}");
                    Options.Choice2A();
                }
                if (input == "B")
                {
                    Console.WriteLine($"You have chosen to {OptionB}");
                    Options.Choice2B();
                }
            }
            if (Counter == 3)
            {
                string input;
                Console.WriteLine("Which will you choose? A or B?");
                input = Console.ReadLine();
                input = input.ToUpper();
                if (input == "A")
                {
                    Console.WriteLine($"You have chosen to {OptionA}");
                    Options.Choice3A();
                }
                if (input == "B")
                {
                    Console.WriteLine($"You have chosen to {OptionB}");
                    Options.Choice3B();
                }
            }


            Counter++;
        
        }
        public void Gift(string OptionA, string OptionB)
        {
            string input;
            Console.WriteLine("Which will you choose? A or B?");
            input = Console.ReadLine();
            input = input.ToUpper();
            if (input == "A")
            {
                Console.WriteLine($"You have chosen to {OptionA}");
                Finale.badEnding();
            }
            if (input == "B")
            {
                Console.WriteLine($"You have chosen to {OptionB}");
                Finale.goodEnding();
            }
        }
    }
}
