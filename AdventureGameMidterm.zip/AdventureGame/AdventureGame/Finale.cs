﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdventureGame
{
    class Finale:Options
    {
        public static void goodEnding()
        {
            Console.WriteLine("You grab the woman's gym bag and start sprinting toward the suited man. You retrieve the emerald as you furiously push against the wind. You drop the bag and hold out the emerald, still running.");
            Game.Dialog("Here!", "yellow");
            Console.WriteLine("The suited man turns to you.");
            Game.Dialog("Is this what you want?", "yellow");
            Console.WriteLine("The man holds his hand out in a claw and the emerald flies out of your hand into his. His cyan eyes are locked onto the rock as they fade and relax. The beams of energy recede and the wind dies down. You look around and things have returned to normal. The man and woman you've been working with are safe. Your eyes return to the suited man and in his hands, where the emerald just was, is a small black velvet box with a ring inside. The ring has a beautiful green stone in it.");
            Game.Dialog("Thank you for returning this,");
            Console.WriteLine(" the suited man says as he pockets the ring.");
            Game.Dialog("You're welcome.", "yellow");
            Player.addScore();
            Player.addScore();
            Player.addScore();
            Console.WriteLine("The lobby begins to fill with guests. Every one of them looks as if they've been through something similar to what you just did. All of them except a woman in a green dress.");
            Console.WriteLine("You exhale and walk toward the front doors. You turn to take one last look before you finally leave the hotel. You see the suited man and the woman in green lock eyes. He reaches into his pocket.");
            Console.WriteLine("");
            Console.WriteLine("Press enter to continue.");
            Console.ReadLine();
            Console.Clear();
            Game.endGame();
        }
        public static void badEnding()
        {
            Game.Dialog("We have to escape.", "yellow");
            Console.WriteLine("The three of you sprint toward the entrance. You trip over your own feet as you pass through the doors and land outside. The doors slam closed behind you. The three of you have escaped, but the hotel is still in turmoil. You try to ignore the distressing sounds coming from within the hotel as you walk away, but you can't shake the feeling you could've done more.");
            Console.WriteLine("");
            Console.WriteLine("Press enter to continue.");
            Console.ReadLine();
            Game.endGame();
        }
    }
}
