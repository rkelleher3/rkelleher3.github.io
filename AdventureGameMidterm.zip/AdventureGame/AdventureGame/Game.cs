﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdventureGame
{
    public static class Game
    {


        public static void startGame()
        {
            Console.WriteLine("Montgomery Hotel");
            Console.WriteLine("You've recently booked a stay at the Montgomery Hotel on a trip to visit family. Unbeknownst to you, this is no ordinary\nhotel. Your first night goes well, but once you try to leave your room, you find yourself in a dim, concrete room with \nno windows and one wooden door. The door to your room locks behind you. \nYou don't know what's going on but you do know one thing: escaping must be your first priority.");
            Player.nameCharacter();
        }

        public static void Dialog(string message)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(message);
            Console.ResetColor();
        }
        public static void Dialog(string message, string color)
        {
            if (color == "red")
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            else if (color == "green")
            {
                Console.ForegroundColor = ConsoleColor.Green;
            }
            else if (color == "yellow")
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.White;
            }

            Console.WriteLine(message);
            Console.ResetColor();
        }


        public static void endGame()
        {
            Console.WriteLine("You have found some items along your way:");
            Item.print();
            Player.printScore();
            Console.ReadKey();
        }

    }
    
    
}
