﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdventureGame
{
    public class Item
    {
        public string Name;
        public string Description;
        public static List<string> myItems = new List<string>();
        public static void addLadder()
        {
            myItems.Add("Ladder");
        }
        public static void addRope()
        {
            myItems.Add("Rope");
        }
        public static void addKey()
        {
            myItems.Add("Key");
        }
        public static void wall()
        {
            if (myItems.Contains("Rope"))
            {
                Console.WriteLine("The woman grabs the rope from your hands and throws it over a hook in the ceiling. She ties a knot and tightens it, creating a secure method of scaling the wall. You each take turns hoisting yourselves over the wall using this rope. When the woman, who's the last one up, reaches the top, she unties the knot and keeps the rope with her.");
            }
            if (myItems.Contains("Ladder"))
            {
                Console.WriteLine("The man grabs the ladder from your hands and places it against the wall. It isn't quite tall enough, but once he reaches the top, he's able to help you and the woman over the wall. You two jump down on the other side and the man is able to reach the ladder and bring it with when he comes down.");
            }
        }
        public static void hatch()
        {
            if (myItems.Contains("Rope")) 
            {
                Game.Dialog("We can throw the rope through that handle and pull it down", "green");
                Game.Dialog("Great idea!", "red");
                Console.WriteLine("The woman twirls the end of the rope a few times to build momentum and throws it through the handle. A perfect toss. You grab the rope on the other side and you work together to open the hatch.");
                Game.Dialog("Get ready to catch it.", "yellow");
                Game.Dialog("I'm ready!", "green");
                Console.WriteLine("The rectangular panel swings open and a glowing green rock falls into the man's hands.");
                myItems.Add("Emerald");
                Game.Dialog("Well what could we ever use this for?","green");
                Game.Dialog("I don't know but it's here for a reason. Just let me keep it in my gym bag.","red");
                Console.WriteLine("The man hands the woman the emerald and she places it in her bag.");
            }
            else
            {
                Game.Dialog("There's nothing to lean the ladder against.", "green");
                Game.Dialog("I knew we should have taken the rope.", "red");
                Game.Dialog("Okay, I made the wrong decision, I'm sorry. We have to keep moving.", "yellow");
            }
        }
        public static void gift()
        {
            if (myItems.Contains("Emerald"))
            {
                Console.WriteLine("What will you do?");
                Console.WriteLine("A) Run. We don't know what this man wants and we need to prioritize our own safety.");
                Console.WriteLine("B) Give the man the Emerald. We don't know how many people are also trapped in this hotel and we need to put a stop to this.");
                Choice choice = new Choice();
                choice.Gift("flee", "fight");
            }
            else
            {
                Game.Dialog("We have no choice. He's clearly looking for something and we have nothing he would want.","yellow");
                Finale.badEnding();
            }
        }
        public static void print()
        {
            foreach (string item in myItems)
            {
                Console.WriteLine(item);
            }
        }
    }
}
