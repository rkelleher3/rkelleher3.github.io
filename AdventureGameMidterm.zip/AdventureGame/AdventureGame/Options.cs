﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdventureGame
{
    class Options
    {
        public static void Choice1A()
        {
            Player.addScore();
            Console.WriteLine("You turn to the man.");
            Game.Dialog("Hey, can you try to reach that lightbulb? I think it has the key in it.", "yellow");
            Game.Dialog("Sure.", "green");
            Console.WriteLine("The man tries and fails to reach the lightbulb with his hand. Eventually he unbuckles his belt and swings it above his head. The metal buckle connects with the bulb. The room goes dark and you hear a light metallic object hit the floor.");
        }
        public static void Choice1B()
        {
            Player.addScore();
            Console.WriteLine("You turn to the woman.");
            Game.Dialog("Hey, I think that lightbulb has a key in it. Do you have anything in your bag that can break it?", "yellow");
            Game.Dialog("Yeah I think I have something that will work.", "red");
            Console.WriteLine("The woman retrieves a small hand weight and throws it at the bulb. It connects, shattering the light and plunging the room into darkness. You hear the weight hit the floor followed by a light metallic object.");
        }
        public static void Choice2A()
        {
            Game.Dialog("Hey don't you have a laptop bag? Can we use something in there to illuminate the room?", "yellow");
            Game.Dialog("Yeah I have a laptop, one second.", "green");
            Console.WriteLine("You hear the man shuffling toward his bag and opening it. Faint blue light fills the room and you begin searching for the key.");
            Game.Dialog("Found it!", "red");
            Item.addKey();
            Player.addScore();
            Console.WriteLine("The woman runs toward the far corner of the room and picks up the key. You all approach the door as she inserts it and turns the handle.");
        }
        public static void Choice2B()
        {
            Game.Dialog("Hey, don't you have a lighter that can illuminate the room?", "yellow");
            Game.Dialog("Sure that might work.", "red");
            Console.WriteLine("You hear a few clicks and then a small flame dimly lights the room. You squint, trying to search for the key on the ground.");
            Game.Dialog("I see it!", "green");
            Item.addKey();
            Player.addScore();
            Console.WriteLine("The man runs toward the far corner of the room and picks up the key. You all approach the door as he inserts it and turns the handle.");
        }
        public static void Choice3A()
        {
            Console.WriteLine("You run toward the rope, grabbing it off the conveyor belt and putting it over your shoulder. You turn to watch as the wooden ladder is plunged into the flames.");
            Item.addRope();
            Player.addScore();
        }
        public static void Choice3B()
        {
            Console.WriteLine("You sprint toward the ladder, yanking it toward you to save it from the furnace. You turn to look as the rope is dropped into the flames.");
            Item.addLadder();
            Player.addScore();
        }
    }
}
