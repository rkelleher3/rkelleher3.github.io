﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdventureGame
{
    public class Player
    {
        static string characterName;
        static int characterScore = 0;

        public static void addScore()
        {
            characterScore++;
        }
        public static void nameCharacter()
        {
            Console.WriteLine("What is your character's name?");
            characterName = Console.ReadLine();
            Console.WriteLine("Your character is now named " + characterName + ". Good luck.");
            Console.WriteLine("Press enter to begin.");
            Console.ReadLine();
            Console.Clear();
        }
        public static void printScore()
        {
            Console.WriteLine($"Congratulations, {characterName}, you have received a score of {characterScore}.");
        }
    }
}
