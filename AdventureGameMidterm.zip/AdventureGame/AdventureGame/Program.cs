﻿/*
 * Montgomery Hotel
 * by Ryan Kelleher, 9/19/2021
 * 
 * This work is a derivative of
 * "C# Adventure Game" by http://programmingisfun.com, used under CC BY.
 * https://creativecommons.org/licenses/by/4.0/
 * ASCII art from network.science.de/ascii/
 * 
 */

using System;
using System.Collections.Generic;

namespace AdventureGame
{
    
    class Program
    {
        public static void Main()
        {
            Console.Title = "Montgomery Hotel";
            string title = @"          __  __             _                                        
         |  \/  |           | |                                       
         | \  / | ___  _ __ | |_ __ _  ___  _ __ ___   ___ _ __ _   _ 
         | |\/| |/ _ \| '_ \| __/ _` |/ _ \| '_ ` _ \ / _ \ '__| | | |
         | |  | | (_) | | | | || (_| | (_) | | | | | |  __/ |  | |_| |
         |_|  |_|\___/|_| |_|\__\__, |\___/|_| |_| |_|\___|_|   \__, |
                                 __/ |                           __/ |
                                |___/                           |___/ 
                             _    _       _       _ 
                            | |  | |     | |     | |
                            | |__| | ___ | |_ ___| |
                            |  __  |/ _ \| __/ _ \ |
                            | |  | | (_) | ||  __/ |
                            |_|  |_|\___/ \__\___|_|
                                                    
                                                    ";
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(title);
            Console.ResetColor();
            Console.WriteLine("Press enter to begin.");
            Console.ReadKey();
            Console.Clear();
            Game.startGame();
            Game.Dialog("I do not have time for this today.", "red");
            Console.WriteLine("A few feet to your right, a woman with a cigarette in her hand grumbles to herself as she tries to reopen her hotel room door. To your left, a man sits on the ground cleaning his glasses. He notices you and stands, beginning to speak.");
            Game.Dialog("Oh my god, new people! I've been here for a half an hour. We need to work together to escape.", "green");
            Game.Dialog("Okay. Whatever gets me out of here the fastest. What do we do about that?", "red");
            Console.WriteLine("The woman points to a padlock on the only door out. The only other thing in the room is a lone light bulb hanging about 12 feet off the ground. You notice that the bulb casts a shadow in the shape of a key below it. Who do you choose to help?");
            Console.WriteLine("A) The man. He's taller and more likely to reach the bulb.");
            Console.WriteLine("B) The woman. She has a gym bag that could contain something you can use.");
            Choice choice = new Choice();
            choice.Decide("ask the man","ask the woman");
            Console.WriteLine("You've freed the key, but the room is now pitch black. Who do you ask for assistance in lighting the room?");
            Console.WriteLine("A) The man has a laptop bag, surely something in there can light up.");
            Console.WriteLine("B) The woman was smoking a cigarette. Maybe she has a lighter that can help illumate the room.");
            choice.Decide("ask the man about his laptop bag", "ask the woman about her lighter");
            Console.WriteLine("Press enter to progress to the next room.");
            Console.ReadLine();
            Player.addScore();
            Console.Clear();
            Console.WriteLine("The three of you step into the next room and see two conveyor belts moving in opposite directions. On one sits a length of rope and on the other, a wooden ladder. At the end of both conveyor belts is a burning furnace. You only have time to save one before the other is completely torched. Which will you choose?");
            Console.WriteLine("A) Save the rope. It's more versatile.");
            Console.WriteLine("B) Save the ladder. It's more reliable.");
            choice.Decide("save the rope", "save the ladder");
            Game.Dialog("Good thinking. That can come in handy later.", "green");
            Game.Dialog("Well the next door is open so let's keep moving", "red");
            Console.WriteLine("Press enter to continue");
            Console.ReadLine();
            Player.addScore();
            Console.Clear();
            Console.WriteLine("You continue into the following room and find yourself at the bottom of a large wall.");
            Item.wall();
            Console.WriteLine("You all reach the other side safely. But this room isn't over just yet.");
            Game.Dialog("Hey, what is that?", "red");
            Console.WriteLine("The woman gestures to the ceiling above you. You all look up to see a rectangular cutout on the ceiling and a handle beneath it.");
            Game.Dialog("I think if we can open that hatch, we can get something else that can help.","red");
            Item.hatch();
            Console.WriteLine("The next door doesn't look like the previous ones. This one is red with gold accents, looking very luxurious. The three of you approach the door and you turn the handle. It's already unlocked.");
            Console.WriteLine("Press enter to continue into the next room.");
            Console.ReadLine();
            Player.addScore();
            Console.Clear();
            Console.WriteLine("The three of you enter the next room and look around.");
            Game.Dialog("I know this place!", "green");
            Game.Dialog("Yeah, we all do. This is the hotel's lobby.", "red");
            Console.WriteLine("She's right, this is the exact lobby you walked through when you chekced in. But now, the entire room is filled with strong winds. You all struggle to stay standing. On the far wall, you see a man in a grey suit behind the front desk. He seems to be angrily searching for something, throwing papers and files everywhere. His eyes are glowing a bright blue and identically-colored beams of energy extend from his body to the corners of the room.");
            Console.WriteLine("You glance at the people beside you, both of them have also noticed the man. You're all frozen in your tracks.");
            Game.Dialog("I think he's looking for something.", "red");
            Game.Dialog("I think he's responsible for all of this.", "yellow");
            Game.Dialog("Guys, look! The front door is open. We can finally escape!", "green");
            Console.WriteLine("You tear your eyes away from the suited man to look toward the front door. He's right. You finally have a clear path to freedom.");
            Game.Dialog("No, we can't leave yet! This man is responsible for all of this, we have to stop him!", "red");
            Item.gift();

        }
    }
}
