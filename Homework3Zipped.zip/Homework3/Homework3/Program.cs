﻿using System;

namespace Homework3
{
    class Program
    {
        static void Main()
        {
            string[] items = { "banana", "orange", "avocado" };
            Console.WriteLine(items[0]);
            Console.WriteLine(items[1]);
            Console.WriteLine(items[2]);
            Console.ReadLine();
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(i);
            }
            for (int j = 9; j > -1; j--)
            {
                Console.WriteLine(j);
            }

            string[] lunch = new string[3];
            lunch[0] = "sandwich";
            lunch[1] = "drink";
            lunch[2] = "apple";
            for (int i = 0; i < lunch.Length; i++)
            {
                Console.WriteLine("The value at " + i + " is " + lunch[i]);
            }
            Console.ReadKey();

            string[] items2 =
            {
                "bananas",
                "orange",
                "avocado",
                "pretzels",
                "lemon",
                "pecans"
            };
            foreach (string element in items2)
            {
                Console.WriteLine(element);
            }
            Console.ReadLine();

        }
    }
}
