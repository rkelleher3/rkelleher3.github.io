﻿using System;

namespace MadLib1
{
    static class MadLibGame
    {
        static string Creature;
        static string Luminous;
        static string Ghastly;
        static string Spectral;
        static string Countryman;
        static string Farrier;
        static string Farmer;
        static string Dreadful;
        static string Apparition;
        static string Hellhound;
        static string Story;

        public static void Run()
        {
            Console.WriteLine("---------");
            Console.WriteLine("MAD-LIB!");
            Console.WriteLine("---------");
            Console.WriteLine("Please enter a noun.");
            Creature = Console.ReadLine();
            Console.WriteLine("Please enter an adjective.");
            Luminous = Console.ReadLine();
            Console.WriteLine("Please enter an adjective.");
            Ghastly = Console.ReadLine();
            Console.WriteLine("Please enter an adjective.");
            Spectral = Console.ReadLine();
            Console.WriteLine("Please enter an occupation.");
            Countryman = Console.ReadLine();
            Console.WriteLine("Please enter an occupation.");
            Farrier = Console.ReadLine();
            Console.WriteLine("Please enter an occupation.");
            Farmer = Console.ReadLine();
            Console.WriteLine("Please enter an adjective.");
            Dreadful = Console.ReadLine();
            Console.WriteLine("Please enter a noun.");
            Apparition = Console.ReadLine();
            Console.WriteLine("Finally, please enter a noun.");
            Hellhound = Console.ReadLine();
            Story = "They all agreed that it was a huge " + Creature + ", " + Luminous + ", " + Ghastly + ", and " + Spectral + ". I have cross-examined these men, one of them a hard-headed " + Countryman + ", one a " + Farrier + ", and one a moorland " + Farmer + ", who all tell the same story of this " + Dreadful + " " + Apparition + ", exactly corresponding to the " + Hellhound + " of the legend.";
            Console.WriteLine(Story);
            Console.WriteLine("Press enter to exit.");
            Console.ReadKey();
        }
    }
    class Program
    {
        static void Main()
        {
            MadLibGame.Run();
        }
    }
}
