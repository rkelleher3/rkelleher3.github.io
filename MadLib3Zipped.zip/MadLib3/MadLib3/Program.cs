﻿using System;

namespace MadLib3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Make a MadLib!";
            string[] words =
             {
                "creature",
                "luminous",
                "ghastly",
                "spectral",
                "countryman",
                "farrier",
                "farmer",
                "dreadful",
                "apparition",
                "hound"
            };
            string[] prompts =
            {
                "noun",
                "adjective",
                "adjective",
                "adjective",
                "occupation",
                "occupation",
                "occupation",
                "adjective",
                "noun",
                "noun"
            };
            for (int i = 0; i < words.Length; i++)
            {
                Console.Write("Please enter a/an " + prompts[i] + ".");
                words[i] = Console.ReadLine();
            }
        }
    }
}
