﻿using System;

namespace test1
{
    class Program
    {
        static void Main()
        {
            double price;
            double tax;
            double total;
            Console.WriteLine("Please enter your item's price.");
            price = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Please enter the tax multiplier.");
            tax = Convert.ToDouble(Console.ReadLine());
            total = (price * tax) + price;
            Console.WriteLine("Your final total is " + total+".");
            Console.ReadKey();

        }
    }
}
